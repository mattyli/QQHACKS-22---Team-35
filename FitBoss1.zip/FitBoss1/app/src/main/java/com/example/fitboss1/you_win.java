package com.example.fitboss1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class you_win extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_you_win);
    }
}