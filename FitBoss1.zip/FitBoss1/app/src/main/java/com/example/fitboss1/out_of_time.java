package com.example.fitboss1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class out_of_time extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_out_of_time);
    }
}